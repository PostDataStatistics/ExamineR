
################################################################################
# StudentR PostData Statistics: 
# Fernando San Segundo, Marcos Marva
# Web: www.postdata-statistics.com
# Mail: postdatastatistics@gmail.com        (secondary: marcos.marva@gmail.es)
################################################################################

################################################################################
# Basic template: given a list of students (see format below) and a vector of 
# questions (in Rnw format, suitable for the R-exams package)
# provides an exam for each student, the solution of each exam 
# and a csv file with the student's details and the answers
################################################################################
# do not forget
# * Set the working directory
# * Customize the templates for the exam and the answers if needed
# * Provide a csv file (separator = , ) with the students details. Two columns, column 1: student_surname, column2 = student_name
################################################################################

# clean the environment, get the working directory ######################################################################
rm(list=ls())
(odir=getwd())
(dirTemporal=paste(odir,"/temp",sep=""))

# load required libraries. If not installed, uncomment the next code line (only needed once)
# install.packages("exams"), install.packages("gdata")
library("exams")
library("gdata")
########################################################################################################################


# Set up the language and the templates for your exam ##################################################################
language='en'
(templateExam=paste("Exam",".tex",sep="",collapse=""))
(templateAnswer=paste("Answer",".tex",sep="",collapse=""))

# Read the templates where to substitute the student's details 
ExamText=scan(file = templateExam, character(0), sep = "\n")
ExamAns=scan(file = templateAnswer, character(0), sep = "\n")

# Get students details from a table  
students = read.table(file = "studentsList.csv", header=FALSE, sep="," , encoding = "utf-8")
students =trim(students)
examNumber = length(students[,1])
#######################################################################################
#### set the number of questions
nQuestions = 10
############################################


# Create a table to gather the answers to each student's quiz #########################################################
studentNumber=c(rep(x=0, times=examNumber))
studentSurname=c(rep(x="name", times=examNumber))
studentName=c(rep(x="surmane(s)", times=examNumber))
studentSolutionsFile=data.frame(studentNumber, studentName, studentSurname, stringsAsFactors=FALSE)
nam=NULL
for (k in (1:nQuestions)){
   studentSolutionsFile=data.frame(studentSolutionsFile,c(0))
   nam <- c(nam, paste("q", k, sep = ""))
}
colnames(studentSolutionsFile) = c("studentNumber","studentSurname", "studentName",nam)
# Add students details
studentSolutionsFile[, 1] <- 1:examNumber
studentSolutionsFile[, 2:3] <- students[, 1:2]
########################################################################################################################


# generate each student's exam and gather the solutions ################################################################
solsExams = c()

for(k in 1:examNumber){
  # Select the questions for the exam ####################################################################################
  theQuestions=c(sample(c('000001','000004'), size = 1),
                sample(c('01010101', '01010301', '01020101', '01020201')),
                sample(c('01030401','01030402'), size = 1),
                sample(c('020001','020003','020004'), size = 1),
               '020203', sample(c('020601','020602'), size = 1)
       )
  theQuiz=paste(theQuestions, ".Rnw", sep = "")
     
     
  # Replace current student's details in the templates    
  templateExamAux = sub(pattern="studentNumber", replacement = k, x = ExamText)
  templateExamAux = sub(pattern="currentStudent", replacement = paste(students[k,1], ", ", students[k,2]), x = templateExamAux)

  # Comment the following 2 code lines if you do not want a copy of each quiz that includes the solution
  # regardless of it, the script will print a table gathering the solutions and the student's details
  templateAnswerAux=sub(pattern="studentNumber", replacement = k, x = ExamAns)
  templateAnswerAux=sub(pattern="currentStudent", replacement = paste(students[k,1], ", ", students[k,2]), x = templateAnswerAux)
    
  # Create appropriate template
  fileQuizAux = paste(k,"-",paste(gsub(" ", "", students[k,1], fixed = TRUE),gsub(" ", "", students[k,2]),".tex", sep= ""), sep = "")
  fileAnswerAux = paste(k,"-",paste(gsub(" ", "", students[k,1], fixed = TRUE),gsub(" ", "", students[k,2]),"Answer.tex", sep= ""), sep = "")
  cat(templateExamAux, file = fileQuizAux, sep="\n")
  cat(templateAnswerAux, file=fileAnswerAux, sep="\n")

  templateExam = fileQuizAux
  templateAnswer =fileAnswerAux

  
  # Print pdfs (quiz and answers) and get the metadata that contains the solution of each exercise ##############################
  meta <- as.vector(unlist(metadata <- exams2pdf(theQuiz, dir=odir, template=c(templateExam,templateAnswer), n=1) ), mode = "character" )

  questionType = rep("", times = nQuestions)
  questionType[which(grepl(pattern = "mchoice", metadata[[1]]))] <- "mchoice"
  questionType[which(grepl(pattern = "num", metadata[[1]]))] <- "num"

  for(j in 1:nQuestions){
       if(questionType[j] == "mchoice"){currentSol = gsub(pattern = ": ", replacement = "", x = metadata[[1]][[j]]$string)}
       if(questionType[j] == "num"){currentSol=metadata[[1]][[j]]$solution}
   solsExams = c(solsExams, currentSol)
  }

  # Delete useless auxiliary templates
  file.remove(templateExam)
  file.remove(templateAnswer)
}
##############################################################################################################################


# Fill the data.frame with the students details and the solutions of each student's quiz #####################################
# write it in an *.csv file 
solsExams.df = as.data.frame(matrix(solsExams, ncol = nQuestions, byrow = TRUE))
studentSolutionsFile[, 4:(3+nQuestions)] <- solsExams.df
write.table(studentSolutionsFile,file="studentSolutionsFile.csv", sep=";", row.names=FALSE)
#############################################################################################################################

# Just to kwon that the compilation has finished
2*2
      
        